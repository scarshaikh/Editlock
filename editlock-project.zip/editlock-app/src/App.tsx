import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { DemoProvider } from './context/DemoContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import HowItWorks from './pages/HowItWorks';
import Features from './pages/Features';
import Pricing from './pages/Pricing';
import Dashboard from './pages/Dashboard';
import Upload from './pages/Upload';
import ProjectDetails from './pages/ProjectDetails';
import ClientPreview from './pages/ClientPreview';
import PaymentDemo from './pages/PaymentDemo';
import Download from './pages/Download';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Help from './pages/Help';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';

export default function App() {
  return (
    <DemoProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/how-it-works" element={<HowItWorks />} />
            <Route path="/features" element={<Features />} />
            <Route path="/pricing" element={<Pricing />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/upload" element={<Upload />} />
            <Route path="/project/:id" element={<ProjectDetails />} />
            <Route path="/preview/:link" element={<ClientPreview />} />
            <Route path="/payment/:id" element={<PaymentDemo />} />
            <Route path="/download/:id" element={<Download />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/help" element={<Help />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </DemoProvider>
  );
}
