import type { Project, DemoUser } from '../types';

// Sample public video URLs for demo (Big Buck Bunny - Creative Commons)
const SAMPLE_VIDEO = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
const SAMPLE_VIDEO_2 = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4';

export const DEMO_USER: DemoUser = {
  id: 'editor-1',
  name: 'Alex Rivera',
  email: 'alex@editlock.demo',
  role: 'editor',
};

export const SAMPLE_PROJECTS: Project[] = [
  {
    id: 'proj-001',
    title: 'Brand Promo – Summit Coffee',
    clientName: 'Jordan Lee',
    clientEmail: 'jordan@summitcoffee.demo',
    description: '30-second product launch promo with motion graphics and color grade.',
    createdAt: '2026-10-01T10:00:00Z',
    updatedAt: '2026-10-10T14:30:00Z',
    status: 'awaiting_payment',
    paymentStatus: 'pending',
    amount: 850,
    currency: 'USD',
    previewUrl: SAMPLE_VIDEO,
    finalUrl: SAMPLE_VIDEO,
    watermarkText: 'PREVIEW – EditLock Demo',
    privateLink: 'demo-summit-coffee-001',
    notes: 'Client requested two revision rounds. Final cut approved.',
  },
  {
    id: 'proj-002',
    title: 'Wedding Highlight Reel – Chen',
    clientName: 'Sam Chen',
    clientEmail: 'sam@example.demo',
    description: 'Cinematic 4-minute highlight reel with licensed music.',
    createdAt: '2026-09-15T09:00:00Z',
    updatedAt: '2026-10-05T11:00:00Z',
    status: 'unlocked',
    paymentStatus: 'verified',
    amount: 1200,
    currency: 'USD',
    previewUrl: SAMPLE_VIDEO_2,
    finalUrl: SAMPLE_VIDEO_2,
    watermarkText: 'PREVIEW – EditLock Demo',
    privateLink: 'demo-chen-wedding-002',
  },
  {
    id: 'proj-003',
    title: 'YouTube Channel Intro Pack',
    clientName: 'Taylor Brooks',
    clientEmail: 'taylor@creators.demo',
    description: 'Animated intros, outros, and lower-thirds package.',
    createdAt: '2026-10-08T16:00:00Z',
    updatedAt: '2026-10-12T09:15:00Z',
    status: 'preview_ready',
    paymentStatus: 'pending',
    amount: 450,
    currency: 'USD',
    previewUrl: SAMPLE_VIDEO,
    finalUrl: SAMPLE_VIDEO,
    watermarkText: 'PREVIEW – EditLock Demo',
    privateLink: 'demo-youtube-intros-003',
  },
  {
    id: 'proj-004',
    title: 'Corporate Training Series – Ep 1',
    clientName: 'Morgan Patel',
    clientEmail: 'morgan@acmecorp.demo',
    description: 'First episode of internal training series with captions.',
    createdAt: '2026-09-20T08:00:00Z',
    updatedAt: '2026-10-01T17:00:00Z',
    status: 'completed',
    paymentStatus: 'verified',
    amount: 2100,
    currency: 'USD',
    previewUrl: SAMPLE_VIDEO_2,
    finalUrl: SAMPLE_VIDEO_2,
    watermarkText: 'PREVIEW – EditLock Demo',
    privateLink: 'demo-acme-training-004',
  },
];

export function getProjectById(id: string): Project | undefined {
  return SAMPLE_PROJECTS.find((p) => p.id === id);
}

export function getProjectByLink(link: string): Project | undefined {
  return SAMPLE_PROJECTS.find((p) => p.privateLink === link);
}
