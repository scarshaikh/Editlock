import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import type { Project, PaymentStatus, ProjectStatus } from '../types';
import { SAMPLE_PROJECTS } from '../data/sampleData';

interface DemoContextType {
  projects: Project[];
  isLoggedIn: boolean;
  login: () => void;
  logout: () => void;
  updatePaymentStatus: (projectId: string, status: PaymentStatus) => void;
  unlockProject: (projectId: string) => void;
  addProject: (project: Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'privateLink' | 'previewUrl' | 'finalUrl' | 'watermarkText'>) => Project;
}

const DemoContext = createContext<DemoContextType | undefined>(undefined);

export function DemoProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>(SAMPLE_PROJECTS);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const login = useCallback(() => setIsLoggedIn(true), []);
  const logout = useCallback(() => setIsLoggedIn(false), []);

  const updatePaymentStatus = useCallback((projectId: string, status: PaymentStatus) => {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id !== projectId) return p;
        const newStatus: ProjectStatus =
          status === 'verified' ? 'unlocked' : status === 'pending' ? 'awaiting_payment' : p.status;
        return {
          ...p,
          paymentStatus: status,
          status: newStatus,
          updatedAt: new Date().toISOString(),
        };
      })
    );
  }, []);

  const unlockProject = useCallback((projectId: string) => {
    setProjects((prev) =>
      prev.map((p) =>
        p.id === projectId
          ? { ...p, status: 'unlocked' as ProjectStatus, paymentStatus: 'verified' as PaymentStatus, updatedAt: new Date().toISOString() }
          : p
      )
    );
  }, []);

  const addProject = useCallback(
    (data: Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'privateLink' | 'previewUrl' | 'finalUrl' | 'watermarkText'>) => {
      const id = `proj-${String(Date.now()).slice(-6)}`;
      const link = `demo-${data.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 20)}-${id.slice(-3)}`;
      const sampleVideo = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
      const newProject: Project = {
        ...data,
        id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        privateLink: link,
        previewUrl: sampleVideo,
        finalUrl: sampleVideo,
        watermarkText: 'PREVIEW – EditLock Demo',
      };
      setProjects((prev) => [newProject, ...prev]);
      return newProject;
    },
    []
  );

  return (
    <DemoContext.Provider
      value={{ projects, isLoggedIn, login, logout, updatePaymentStatus, unlockProject, addProject }}
    >
      {children}
    </DemoContext.Provider>
  );
}

export function useDemo() {
  const ctx = useContext(DemoContext);
  if (!ctx) throw new Error('useDemo must be used within DemoProvider');
  return ctx;
}
