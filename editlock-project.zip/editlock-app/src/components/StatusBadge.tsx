import type { PaymentStatus, ProjectStatus } from '../types';

const paymentMap: Record<PaymentStatus, { label: string; className: string }> = {
  pending: { label: 'Pending', className: 'badge-warning' },
  verified: { label: 'Verified', className: 'badge-success' },
  failed: { label: 'Failed', className: 'badge-danger' },
  refunded: { label: 'Refunded', className: 'badge-neutral' },
};

const projectMap: Record<ProjectStatus, { label: string; className: string }> = {
  draft: { label: 'Draft', className: 'badge-neutral' },
  preview_ready: { label: 'Preview Ready', className: 'badge-info' },
  awaiting_payment: { label: 'Awaiting Payment', className: 'badge-warning' },
  unlocked: { label: 'Unlocked', className: 'badge-success' },
  completed: { label: 'Completed', className: 'badge-success' },
};

export function PaymentBadge({ status }: { status: PaymentStatus }) {
  const { label, className } = paymentMap[status];
  return <span className={className}>{label}</span>;
}

export function ProjectBadge({ status }: { status: ProjectStatus }) {
  const { label, className } = projectMap[status];
  return <span className={className}>{label}</span>;
}
