import { AlertTriangle } from 'lucide-react';

export default function DemoBanner() {
  return (
    <div className="border-b border-amber-500/30 bg-amber-500/10 px-4 py-2.5 text-center text-sm text-amber-200">
      <div className="mx-auto flex max-w-6xl items-center justify-center gap-2">
        <AlertTriangle className="h-4 w-4 shrink-0" />
        <span>
          <strong>Demo only.</strong> No real payments, no real video storage, and no production-grade security.
          All interactions are simulated with sample data.
        </span>
      </div>
    </div>
  );
}
