import { Link } from 'react-router-dom';
import { Lock } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-navy-600 bg-navy-900">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link to="/" className="flex items-center gap-2 text-lg font-bold">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent">
                <Lock className="h-4 w-4 text-white" />
              </span>
              EditLock
            </Link>
            <p className="mt-3 text-sm text-gray-400">
              Protect your creative work. Share previews, verify payments, deliver with confidence.
            </p>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold text-white">Product</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link to="/how-it-works" className="hover:text-white">How It Works</Link></li>
              <li><Link to="/features" className="hover:text-white">Features</Link></li>
              <li><Link to="/pricing" className="hover:text-white">Pricing</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold text-white">Support</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link to="/help" className="hover:text-white">Help & FAQ</Link></li>
              <li><Link to="/terms" className="hover:text-white">Terms of Service</Link></li>
              <li><Link to="/privacy" className="hover:text-white">Privacy Policy</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold text-white">Demo Notice</h4>
            <p className="text-sm text-gray-400">
              This is a functional frontend demo only. No real payments, video storage, or production security.
            </p>
          </div>
        </div>
        <div className="mt-10 border-t border-navy-600 pt-6 text-center text-sm text-gray-500">
          © {new Date().getFullYear()} EditLock Demo. Built for demonstration purposes.
        </div>
      </div>
    </footer>
  );
}
