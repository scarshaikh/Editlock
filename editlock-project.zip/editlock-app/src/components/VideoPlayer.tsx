import { useRef, useState } from 'react';
import { Play, Pause, Volume2, VolumeX } from 'lucide-react';

interface VideoPlayerProps {
  src: string;
  watermark?: string;
  locked?: boolean;
  title?: string;
}

export default function VideoPlayer({ src, watermark, locked = false, title }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(true);

  const togglePlay = () => {
    if (!videoRef.current || locked) return;
    if (playing) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setPlaying(!playing);
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !muted;
    setMuted(!muted);
  };

  return (
    <div className="relative overflow-hidden rounded-xl border border-navy-600 bg-black">
      {title && (
        <div className="absolute left-0 right-0 top-0 z-10 bg-gradient-to-b from-black/70 to-transparent px-4 py-3">
          <p className="text-sm font-medium text-white">{title}</p>
        </div>
      )}
      <video
        ref={videoRef}
        src={src}
        className="aspect-video w-full object-cover"
        muted={muted}
        playsInline
        loop
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
      />
      {watermark && !locked && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <span className="select-none text-2xl font-bold tracking-widest text-white/30 sm:text-4xl">
            {watermark}
          </span>
        </div>
      )}
      {locked && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80">
          <div className="rounded-full bg-navy-700 p-4">
            <svg className="h-10 w-10 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <p className="mt-4 text-lg font-semibold text-white">Download Locked</p>
          <p className="mt-1 text-sm text-gray-400">Payment verification required</p>
        </div>
      )}
      {!locked && (
        <div className="absolute bottom-0 left-0 right-0 flex items-center gap-2 bg-gradient-to-t from-black/80 to-transparent px-4 py-3">
          <button onClick={togglePlay} className="rounded-full bg-white/10 p-2 hover:bg-white/20">
            {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </button>
          <button onClick={toggleMute} className="rounded-full bg-white/10 p-2 hover:bg-white/20">
            {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </button>
          <span className="ml-auto text-xs text-gray-400">Demo sample video</span>
        </div>
      )}
    </div>
  );
}
