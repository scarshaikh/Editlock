export type PaymentStatus = 'pending' | 'verified' | 'failed' | 'refunded';

export type ProjectStatus = 'draft' | 'preview_ready' | 'awaiting_payment' | 'unlocked' | 'completed';

export interface Project {
  id: string;
  title: string;
  clientName: string;
  clientEmail: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  status: ProjectStatus;
  paymentStatus: PaymentStatus;
  amount: number;
  currency: string;
  previewUrl: string; // sample video URL
  finalUrl: string;   // same for demo
  watermarkText: string;
  privateLink: string;
  notes?: string;
}

export interface DemoUser {
  id: string;
  name: string;
  email: string;
  role: 'editor' | 'client';
}
