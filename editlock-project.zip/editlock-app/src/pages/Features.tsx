import { Eye, Link2, BarChart3, Lock, Users, Store, Shield, FileVideo, Bell, Clock } from 'lucide-react';
import DemoBanner from '../components/DemoBanner';

const mainFeatures = [
  {
    icon: Eye,
    title: 'Watermarked Video Preview',
    desc: 'Clients receive a playable preview with a clear, persistent watermark. They can review timing, color, and content without obtaining a usable final master.',
  },
  {
    icon: Link2,
    title: 'Private Project Links',
    desc: 'Each project gets a unique private link. No public directory of projects. Share only with the people who need access.',
  },
  {
    icon: BarChart3,
    title: 'Payment Status Tracking',
    desc: 'See at a glance whether payment is pending, verified, failed, or refunded. Status drives download access automatically in the demo.',
  },
  {
    icon: Lock,
    title: 'Secure Download Access',
    desc: 'The final clean file stays locked until the payment status is set to verified. No more sending the master and hoping the invoice gets paid.',
  },
  {
    icon: Users,
    title: 'Client Project Management',
    desc: 'A single dashboard for all your projects: status, client details, amounts, notes, and quick links to previews and payment demos.',
  },
  {
    icon: Store,
    title: 'Future Marketplace Commission Support',
    desc: 'The data model and flow are designed so a future marketplace layer (with platform fees) can be added without rewriting the core protection logic.',
  },
];

const extras = [
  { icon: Shield, title: 'Demo-safe architecture', desc: 'Built to expand to real auth, storage, and payment webhooks later.' },
  { icon: FileVideo, title: 'Sample media only', desc: 'Uses public Creative Commons sample videos. No user uploads stored.' },
  { icon: Bell, title: 'Clear status badges', desc: 'Consistent visual language for payment and project states.' },
  { icon: Clock, title: 'Responsive UI', desc: 'Works on phones, tablets, and desktops with the same professional look.' },
];

export default function Features() {
  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-3xl font-bold text-white sm:text-4xl">Features</h1>
          <p className="mt-4 text-gray-400">
            Core capabilities of the EditLock demo, designed for professional video editors who need payment protection.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2">
          {mainFeatures.map((f) => (
            <div key={f.title} className="card">
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg bg-accent/15 text-accent">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold text-white">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-gray-400">{f.desc}</p>
            </div>
          ))}
        </div>

        <h2 className="mt-16 text-center text-xl font-semibold text-white">Also included in this demo</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {extras.map((e) => (
            <div key={e.title} className="card flex flex-col items-start gap-2 p-4">
              <e.icon className="h-5 w-5 text-accent" />
              <p className="font-medium text-white">{e.title}</p>
              <p className="text-xs text-gray-400">{e.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
