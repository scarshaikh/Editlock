import { Link } from 'react-router-dom';
import { Check } from 'lucide-react';
import DemoBanner from '../components/DemoBanner';

const plans = [
  {
    name: 'Free Demo',
    price: '$0',
    period: 'forever',
    description: 'Explore the full UI and interactions with sample data.',
    features: [
      'Unlimited sample projects',
      'Watermarked preview simulation',
      'Payment status toggle',
      'Client preview links',
      'No real video storage',
      'No real payments',
    ],
    cta: 'Start Free Demo',
    href: '/signup',
    highlighted: true,
  },
  {
    name: 'Pro (Coming Soon)',
    price: 'TBD',
    period: 'per month',
    description: 'Production-ready protection for working editors.',
    features: [
      'Real video storage & CDN',
      'Payment provider webhooks',
      'Custom watermarks',
      'Team seats',
      'Priority support',
      'Marketplace options',
    ],
    cta: 'Join Waitlist',
    href: '/signup',
    highlighted: false,
  },
];

export default function Pricing() {
  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-3xl font-bold text-white sm:text-4xl">Pricing</h1>
          <p className="mt-4 text-gray-400">
            This version is a free functional demo. Production pricing will be announced when real storage and payment integrations ship.
          </p>
        </div>

        <div className="mx-auto mt-12 grid max-w-4xl gap-6 sm:grid-cols-2">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`card flex flex-col ${plan.highlighted ? 'border-accent/50 ring-1 ring-accent/30' : ''}`}
            >
              <h3 className="text-lg font-semibold text-white">{plan.name}</h3>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="text-3xl font-bold text-white">{plan.price}</span>
                <span className="text-sm text-gray-400">/{plan.period}</span>
              </div>
              <p className="mt-2 text-sm text-gray-400">{plan.description}</p>
              <ul className="mt-6 flex-1 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-gray-300">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                to={plan.href}
                className={`mt-8 w-full ${plan.highlighted ? 'btn-primary' : 'btn-secondary'}`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
