import { Link } from 'react-router-dom';
import { Upload, Eye, CreditCard, Download, ArrowRight, Shield, Link2, BarChart3, Lock, Users, Store } from 'lucide-react';
import DemoBanner from '../components/DemoBanner';

const steps = [
  { icon: Upload, title: 'Video Uploaded', desc: 'Editor uploads the final project' },
  { icon: Eye, title: 'Watermarked Preview', desc: 'Client receives secure preview link' },
  { icon: CreditCard, title: 'Payment Verified', desc: 'Payment status confirmed' },
  { icon: Download, title: 'Final Download', desc: 'Clean file unlocked for client' },
];

const features = [
  { icon: Eye, title: 'Watermarked Video Preview', desc: 'Share previews with persistent watermarks so clients can review without receiving the final file.' },
  { icon: Link2, title: 'Private Project Links', desc: 'Unique, unguessable links for each project. Share only with the intended client.' },
  { icon: BarChart3, title: 'Payment Status Tracking', desc: 'Clear visibility into pending, verified, or failed payments for every project.' },
  { icon: Lock, title: 'Secure Download Access', desc: 'Final downloads remain locked until payment is verified in the system.' },
  { icon: Users, title: 'Client Project Management', desc: 'Organize all client work in one dashboard with status, notes, and history.' },
  { icon: Store, title: 'Future Marketplace Support', desc: 'Architecture ready for optional commission-based marketplace features later.' },
];

export default function Home() {
  return (
    <>
      <DemoBanner />
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-accent/5 to-transparent" />
        <div className="relative mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24 lg:py-28">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
              Your Work. Your Payment.{' '}
              <span className="text-accent">Your Protection.</span>
            </h1>
            <p className="mt-6 text-lg text-gray-300 sm:text-xl">
              Share secure video previews, verify payments, and deliver final projects with confidence.
            </p>
            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link to="/signup" className="btn-primary w-full sm:w-auto">
                Start Free Demo
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/how-it-works" className="btn-secondary w-full sm:w-auto">
                See How It Works
              </Link>
            </div>
          </div>

          {/* Visual flow */}
          <div className="mt-16 sm:mt-20">
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center sm:gap-2">
              {steps.map((step, i) => (
                <div key={step.title} className="flex items-center gap-2">
                  <div className="card flex w-full max-w-[180px] flex-col items-center gap-2 p-4 text-center sm:w-auto">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/20 text-accent">
                      <step.icon className="h-5 w-5" />
                    </div>
                    <p className="text-sm font-semibold text-white">{step.title}</p>
                    <p className="text-xs text-gray-400">{step.desc}</p>
                  </div>
                  {i < steps.length - 1 && (
                    <ArrowRight className="hidden h-5 w-5 shrink-0 text-gray-600 sm:block" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features grid */}
      <section className="border-t border-navy-600 bg-navy-800/50 py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold text-white sm:text-4xl">Built for professional editors</h2>
            <p className="mt-4 text-gray-400">
              Everything you need to protect deliverables and get paid before the final file leaves your hands.
            </p>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <div key={f.title} className="card transition-colors hover:border-accent/40">
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-accent/15 text-accent">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="text-lg font-semibold text-white">{f.title}</h3>
                <p className="mt-2 text-sm text-gray-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust / CTA */}
      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="card flex flex-col items-center gap-6 bg-gradient-to-br from-navy-800 to-navy-700 p-8 text-center sm:p-12">
            <Shield className="h-12 w-12 text-accent" />
            <h2 className="text-2xl font-bold text-white sm:text-3xl">
              Stop chasing invoices after delivery
            </h2>
            <p className="max-w-xl text-gray-300">
              EditLock lets you control access to the final file until payment is confirmed.
              Explore the full demo dashboard and client preview experience.
            </p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Link to="/dashboard" className="btn-primary">
                Open Editor Dashboard
              </Link>
              <Link to="/preview/demo-summit-coffee-001" className="btn-secondary">
                Try Client Preview
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
