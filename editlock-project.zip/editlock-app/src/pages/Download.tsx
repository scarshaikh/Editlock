import { useParams, Link } from 'react-router-dom';
import { useDemo } from '../context/DemoContext';
import VideoPlayer from '../components/VideoPlayer';
import { PaymentBadge } from '../components/StatusBadge';
import { Download as DownloadIcon, Lock, ArrowLeft } from 'lucide-react';
import DemoBanner from '../components/DemoBanner';

export default function Download() {
  const { id } = useParams<{ id: string }>();
  const { projects } = useDemo();
  const project = projects.find((p) => p.id === id);

  if (!project) {
    return (
      <section className="mx-auto max-w-lg px-4 py-20 text-center">
        <h1 className="text-2xl font-bold text-white">Project not found</h1>
        <Link to="/dashboard" className="btn-primary mt-6 inline-flex">
          Back to Dashboard
        </Link>
      </section>
    );
  }

  const isUnlocked = project.paymentStatus === 'verified' || project.status === 'unlocked' || project.status === 'completed';

  const handleDownload = () => {
    if (!isUnlocked) return;
    // Simulate download of sample video
    const a = document.createElement('a');
    a.href = project.finalUrl;
    a.download = `${project.title.replace(/\s+/g, '_')}_final.mp4`;
    a.target = '_blank';
    a.click();
  };

  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-3xl px-4 py-8 sm:px-6 sm:py-12">
        <Link to={`/project/${project.id}`} className="inline-flex items-center gap-1 text-sm text-gray-400 hover:text-white">
          <ArrowLeft className="h-4 w-4" />
          Project details
        </Link>

        <h1 className="mt-4 text-2xl font-bold text-white sm:text-3xl">Download</h1>
        <p className="mt-1 text-gray-400">{project.title}</p>
        <div className="mt-2">
          <PaymentBadge status={project.paymentStatus} />
        </div>

        <div className="mt-8">
          {isUnlocked ? (
            <>
              <VideoPlayer src={project.finalUrl} title="Final version (no watermark)" />
              <div className="card mt-6 text-center">
                <p className="text-emerald-400 font-medium">Payment verified — final file is available</p>
                <p className="mt-1 text-sm text-gray-400">
                  In production this would stream or serve the stored master file. Here a sample video is offered.
                </p>
                <button onClick={handleDownload} className="btn-primary mt-5">
                  <DownloadIcon className="h-4 w-4" />
                  Download Final Video (Demo)
                </button>
              </div>
            </>
          ) : (
            <>
              <VideoPlayer src={project.previewUrl} locked title="Final download locked" />
              <div className="card mt-6 text-center">
                <Lock className="mx-auto h-10 w-10 text-amber-400" />
                <p className="mt-3 font-semibold text-white">Download is locked</p>
                <p className="mt-1 text-sm text-gray-400">
                  Payment status is currently <PaymentBadge status={project.paymentStatus} />. 
                  The final clean file becomes available only after payment is marked verified.
                </p>
                <Link to={`/payment/${project.id}`} className="btn-primary mt-5 inline-flex">
                  Go to Payment Status Demo
                </Link>
              </div>
            </>
          )}
        </div>
      </section>
    </>
  );
}
