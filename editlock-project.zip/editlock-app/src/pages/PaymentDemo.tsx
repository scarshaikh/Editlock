import { useParams, Link } from 'react-router-dom';
import { useDemo } from '../context/DemoContext';
import { PaymentBadge, ProjectBadge } from '../components/StatusBadge';
import type { PaymentStatus } from '../types';
import { CreditCard, CheckCircle, AlertCircle, ArrowLeft } from 'lucide-react';
import DemoBanner from '../components/DemoBanner';

export default function PaymentDemo() {
  const { id } = useParams<{ id: string }>();
  const { projects, updatePaymentStatus } = useDemo();
  const project = projects.find((p) => p.id === id);

  if (!project) {
    return (
      <section className="mx-auto max-w-lg px-4 py-20 text-center">
        <h1 className="text-2xl font-bold text-white">Project not found</h1>
        <Link to="/dashboard" className="btn-primary mt-6 inline-flex">
          Back to Dashboard
        </Link>
      </section>
    );
  }

  const setStatus = (status: PaymentStatus) => {
    updatePaymentStatus(project.id, status);
  };

  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12">
        <Link to={`/project/${project.id}`} className="inline-flex items-center gap-1 text-sm text-gray-400 hover:text-white">
          <ArrowLeft className="h-4 w-4" />
          Project details
        </Link>

        <div className="mt-4">
          <h1 className="text-2xl font-bold text-white">Payment Status Demo</h1>
          <p className="mt-1 text-gray-400">
            Simulate payment verification for <strong className="text-white">{project.title}</strong>
          </p>
        </div>

        <div className="card mt-6">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/15 text-accent">
              <CreditCard className="h-6 w-6" />
            </div>
            <div>
              <p className="font-medium text-white">{project.currency} {project.amount.toLocaleString()}</p>
              <p className="text-sm text-gray-400">{project.clientName} · {project.clientEmail}</p>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <span className="text-sm text-gray-400">Project:</span>
            <ProjectBadge status={project.status} />
            <span className="text-sm text-gray-400">Payment:</span>
            <PaymentBadge status={project.paymentStatus} />
          </div>
        </div>

        <div className="card mt-6">
          <h2 className="font-semibold text-white">Simulate status change</h2>
          <p className="mt-1 text-sm text-gray-400">
            In production this would be driven by payment provider webhooks (Stripe, PayPal, etc.). Here you can toggle the status manually to see how download access responds.
          </p>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <button
              onClick={() => setStatus('pending')}
              className={`btn-secondary justify-start ${project.paymentStatus === 'pending' ? 'ring-2 ring-amber-500' : ''}`}
            >
              <AlertCircle className="h-4 w-4 text-amber-400" />
              Mark Pending
            </button>
            <button
              onClick={() => setStatus('verified')}
              className={`btn-secondary justify-start ${project.paymentStatus === 'verified' ? 'ring-2 ring-emerald-500' : ''}`}
            >
              <CheckCircle className="h-4 w-4 text-emerald-400" />
              Mark Verified
            </button>
            <button
              onClick={() => setStatus('failed')}
              className={`btn-secondary justify-start ${project.paymentStatus === 'failed' ? 'ring-2 ring-red-500' : ''}`}
            >
              Mark Failed
            </button>
            <button
              onClick={() => setStatus('refunded')}
              className={`btn-secondary justify-start ${project.paymentStatus === 'refunded' ? 'ring-2 ring-gray-500' : ''}`}
            >
              Mark Refunded
            </button>
          </div>
        </div>

        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <Link to={`/download/${project.id}`} className="btn-primary">
            View Download Page
          </Link>
          <Link to={`/preview/${project.privateLink}`} className="btn-secondary">
            Client Preview
          </Link>
        </div>

        <div className="mt-8 rounded-lg border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-200">
          <strong>Important:</strong> No real payment is processed. This page only updates local demo state so you can experience the locked/unlocked download flow.
        </div>
      </section>
    </>
  );
}
