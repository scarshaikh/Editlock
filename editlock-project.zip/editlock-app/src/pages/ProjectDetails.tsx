import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Eye, CreditCard, Download, Copy, Check } from 'lucide-react';
import { useState } from 'react';
import { useDemo } from '../context/DemoContext';
import { PaymentBadge, ProjectBadge } from '../components/StatusBadge';
import VideoPlayer from '../components/VideoPlayer';
import DemoBanner from '../components/DemoBanner';

export default function ProjectDetails() {
  const { id } = useParams<{ id: string }>();
  const { projects } = useDemo();
  const project = projects.find((p) => p.id === id);
  const [copied, setCopied] = useState(false);

  if (!project) {
    return (
      <section className="mx-auto max-w-lg px-4 py-20 text-center">
        <h1 className="text-2xl font-bold text-white">Project not found</h1>
        <Link to="/dashboard" className="btn-primary mt-6 inline-flex">
          Back to Dashboard
        </Link>
      </section>
    );
  }

  const previewPath = `/preview/${project.privateLink}`;
  const copyLink = () => {
    navigator.clipboard.writeText(window.location.origin + previewPath);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isUnlocked = project.paymentStatus === 'verified' || project.status === 'unlocked' || project.status === 'completed';

  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-gray-400 hover:text-white">
          <ArrowLeft className="h-4 w-4" />
          Dashboard
        </Link>

        <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white sm:text-3xl">{project.title}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <ProjectBadge status={project.status} />
              <PaymentBadge status={project.paymentStatus} />
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link to={previewPath} className="btn-secondary">
              <Eye className="h-4 w-4" />
              Client Preview
            </Link>
            <Link to={`/payment/${project.id}`} className="btn-secondary">
              <CreditCard className="h-4 w-4" />
              Payment Demo
            </Link>
            <Link to={`/download/${project.id}`} className="btn-primary">
              <Download className="h-4 w-4" />
              Download
            </Link>
          </div>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <VideoPlayer
              src={project.previewUrl}
              watermark={isUnlocked ? undefined : project.watermarkText}
              title={isUnlocked ? 'Final version (demo)' : 'Watermarked preview'}
            />
          </div>
          <div className="space-y-4">
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-400">Client</h3>
              <p className="mt-1 font-medium text-white">{project.clientName}</p>
              <p className="text-sm text-gray-400">{project.clientEmail}</p>
            </div>
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-400">Amount</h3>
              <p className="mt-1 text-xl font-bold text-white">
                {project.currency} {project.amount.toLocaleString()}
              </p>
            </div>
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-400">Private Link</h3>
              <div className="mt-2 flex items-center gap-2">
                <code className="flex-1 truncate rounded bg-navy-900 px-2 py-1 text-xs text-accent">
                  {project.privateLink}
                </code>
                <button onClick={copyLink} className="btn-ghost p-2" title="Copy full URL">
                  {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <div className="card">
              <h3 className="text-sm font-semibold text-gray-400">Description</h3>
              <p className="mt-1 text-sm text-gray-300">{project.description}</p>
              {project.notes && (
                <>
                  <h3 className="mt-4 text-sm font-semibold text-gray-400">Notes</h3>
                  <p className="mt-1 text-sm text-gray-300">{project.notes}</p>
                </>
              )}
            </div>
            <div className="card text-xs text-gray-500">
              Created: {new Date(project.createdAt).toLocaleString()}
              <br />
              Updated: {new Date(project.updatedAt).toLocaleString()}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
