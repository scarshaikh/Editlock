import { useState, FormEvent } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Upload as UploadIcon, Info } from 'lucide-react';
import { useDemo } from '../context/DemoContext';
import DemoBanner from '../components/DemoBanner';

export default function Upload() {
  const { addProject, isLoggedIn, login } = useDemo();
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('500');
  const [notes, setNotes] = useState('');
  const [fileName, setFileName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!isLoggedIn) {
    return (
      <>
        <DemoBanner />
        <section className="mx-auto max-w-lg px-4 py-20 text-center">
          <h1 className="text-2xl font-bold text-white">Sign in required</h1>
          <p className="mt-2 text-gray-400">Enter the demo dashboard first to create projects.</p>
          <button onClick={login} className="btn-primary mt-6">
            Enter Demo Dashboard
          </button>
        </section>
      </>
    );
  }

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      const project = addProject({
        title: title || 'Untitled Project',
        clientName: clientName || 'Demo Client',
        clientEmail: clientEmail || 'client@demo.local',
        description: description || 'No description provided.',
        status: 'preview_ready',
        paymentStatus: 'pending',
        amount: Number(amount) || 0,
        currency: 'USD',
        notes: notes || undefined,
      });
      setSubmitting(false);
      navigate(`/project/${project.id}`);
    }, 600);
  };

  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12">
        <h1 className="text-2xl font-bold text-white sm:text-3xl">Upload Project</h1>
        <p className="mt-1 text-sm text-gray-400">
          Create a new project with sample data. No real file is uploaded or stored.
        </p>

        <div className="mt-4 flex items-start gap-2 rounded-lg border border-blue-500/30 bg-blue-500/10 p-3 text-sm text-blue-200">
          <Info className="mt-0.5 h-4 w-4 shrink-0" />
          <span>
            File upload is simulated. A public sample video will be used for the preview and download demo.
          </span>
        </div>

        <form onSubmit={handleSubmit} className="card mt-6 space-y-5">
          <div>
            <label className="label" htmlFor="title">Project Title</label>
            <input
              id="title"
              className="input"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Brand Promo – Acme Co"
              required
            />
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="clientName">Client Name</label>
              <input
                id="clientName"
                className="input"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="Jordan Lee"
                required
              />
            </div>
            <div>
              <label className="label" htmlFor="clientEmail">Client Email</label>
              <input
                id="clientEmail"
                type="email"
                className="input"
                value={clientEmail}
                onChange={(e) => setClientEmail(e.target.value)}
                placeholder="jordan@client.demo"
                required
              />
            </div>
          </div>
          <div>
            <label className="label" htmlFor="description">Description</label>
            <textarea
              id="description"
              className="input min-h-[80px]"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief project description..."
            />
          </div>
          <div>
            <label className="label" htmlFor="amount">Amount (USD)</label>
            <input
              id="amount"
              type="number"
              min="0"
              step="1"
              className="input"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="label" htmlFor="file">Video File (simulated)</label>
            <div className="flex items-center gap-3">
              <label className="btn-secondary cursor-pointer">
                <UploadIcon className="h-4 w-4" />
                Choose file
                <input
                  id="file"
                  type="file"
                  accept="video/*"
                  className="hidden"
                  onChange={(e) => setFileName(e.target.files?.[0]?.name || '')}
                />
              </label>
              <span className="text-sm text-gray-400">
                {fileName || 'No file selected (sample will be used)'}
              </span>
            </div>
          </div>
          <div>
            <label className="label" htmlFor="notes">Internal Notes (optional)</label>
            <textarea
              id="notes"
              className="input min-h-[60px]"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Revision notes, delivery preferences..."
            />
          </div>
          <div className="flex flex-col gap-3 pt-2 sm:flex-row">
            <button type="submit" className="btn-primary" disabled={submitting}>
              {submitting ? 'Creating...' : 'Create Project'}
            </button>
            <Link to="/dashboard" className="btn-secondary">
              Cancel
            </Link>
          </div>
        </form>
      </section>
    </>
  );
}
