import DemoBanner from '../components/DemoBanner';

export default function Terms() {
  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-16">
        <h1 className="text-3xl font-bold text-white">Terms of Service</h1>
        <p className="mt-2 text-sm text-gray-500">Placeholder — Demo version</p>

        <div className="prose prose-invert mt-8 max-w-none space-y-4 text-sm text-gray-300">
          <p>
            This application is provided solely as a functional demonstration of a video delivery and payment-protection concept. It is not a commercial product.
          </p>
          <p>
            By using this demo you acknowledge that:
          </p>
          <ul className="list-disc space-y-2 pl-5">
            <li>No real user accounts are created or stored.</li>
            <li>No real payments are processed.</li>
            <li>No customer video files are uploaded or retained on any server.</li>
            <li>All project and payment data exists only in browser memory for the current session.</li>
            <li>The software is provided “as is” without warranty of any kind.</li>
          </ul>
          <p>
            A production version of EditLock would include full legal terms covering accounts, acceptable use, payment processing, intellectual property, liability, and dispute resolution. Those terms do not apply to this demo.
          </p>
        </div>
      </section>
    </>
  );
}
