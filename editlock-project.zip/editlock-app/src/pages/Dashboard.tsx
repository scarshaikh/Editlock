import { Link } from 'react-router-dom';
import { Plus, ExternalLink, Eye, CreditCard, FileVideo } from 'lucide-react';
import { useDemo } from '../context/DemoContext';
import { PaymentBadge, ProjectBadge } from '../components/StatusBadge';
import DemoBanner from '../components/DemoBanner';

export default function Dashboard() {
  const { projects, isLoggedIn, login } = useDemo();

  if (!isLoggedIn) {
    return (
      <>
        <DemoBanner />
        <section className="mx-auto max-w-lg px-4 py-20 text-center">
          <FileVideo className="mx-auto h-12 w-12 text-accent" />
          <h1 className="mt-4 text-2xl font-bold text-white">Editor Dashboard</h1>
          <p className="mt-2 text-gray-400">
            This is a demo login. Click below to enter the sample editor account. No real authentication is performed.
          </p>
          <button onClick={login} className="btn-primary mt-6">
            Enter Demo Dashboard
          </button>
          <p className="mt-4 text-sm text-gray-500">
            Or <Link to="/login" className="text-accent hover:underline">go to Login page</Link>
          </p>
        </section>
      </>
    );
  }

  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white sm:text-3xl">Editor Dashboard</h1>
            <p className="mt-1 text-sm text-gray-400">Manage projects, previews, and payment status (demo data).</p>
          </div>
          <Link to="/upload" className="btn-primary">
            <Plus className="h-4 w-4" />
            New Project
          </Link>
        </div>

        <div className="mt-8 overflow-hidden rounded-xl border border-navy-600">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="bg-navy-800 text-gray-400">
                <tr>
                  <th className="px-4 py-3 font-medium">Project</th>
                  <th className="px-4 py-3 font-medium">Client</th>
                  <th className="px-4 py-3 font-medium">Amount</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Payment</th>
                  <th className="px-4 py-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-navy-600">
                {projects.map((p) => (
                  <tr key={p.id} className="bg-navy-900/50 hover:bg-navy-800/50">
                    <td className="px-4 py-3">
                      <Link to={`/project/${p.id}`} className="font-medium text-white hover:text-accent">
                        {p.title}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-gray-300">{p.clientName}</td>
                    <td className="px-4 py-3 text-gray-300">
                      {p.currency} {p.amount.toLocaleString()}
                    </td>
                    <td className="px-4 py-3">
                      <ProjectBadge status={p.status} />
                    </td>
                    <td className="px-4 py-3">
                      <PaymentBadge status={p.paymentStatus} />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Link
                          to={`/project/${p.id}`}
                          className="rounded p-1.5 text-gray-400 hover:bg-navy-700 hover:text-white"
                          title="Details"
                        >
                          <FileVideo className="h-4 w-4" />
                        </Link>
                        <Link
                          to={`/preview/${p.privateLink}`}
                          className="rounded p-1.5 text-gray-400 hover:bg-navy-700 hover:text-white"
                          title="Client Preview"
                        >
                          <Eye className="h-4 w-4" />
                        </Link>
                        <Link
                          to={`/payment/${p.id}`}
                          className="rounded p-1.5 text-gray-400 hover:bg-navy-700 hover:text-white"
                          title="Payment Demo"
                        >
                          <CreditCard className="h-4 w-4" />
                        </Link>
                        <a
                          href={`/preview/${p.privateLink}`}
                          target="_blank"
                          rel="noreferrer"
                          className="rounded p-1.5 text-gray-400 hover:bg-navy-700 hover:text-white"
                          title="Open link"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {projects.length === 0 && (
          <div className="mt-12 text-center text-gray-400">
            No projects yet. <Link to="/upload" className="text-accent hover:underline">Create one</Link>.
          </div>
        )}
      </section>
    </>
  );
}
