import DemoBanner from '../components/DemoBanner';

const faqs = [
  {
    q: 'Is this a real production product?',
    a: 'No. EditLock is a functional frontend demo. It uses sample data and simulated interactions only. No real payments, video storage, or production security are implemented.',
  },
  {
    q: 'How do I try the full flow?',
    a: '1) Click “Enter Demo Dashboard” or sign up. 2) Create a project or open an existing one. 3) Open the Client Preview link. 4) Go to Payment Status Demo and mark payment as Verified. 5) Return to the Download page — the final file unlocks.',
  },
  {
    q: 'Why is the video watermarked?',
    a: 'Watermarked previews let clients review the work without receiving a usable final master. In a real system the watermark would be burned into the video stream or file.',
  },
  {
    q: 'Can I upload my own videos?',
    a: 'In this demo, file selection is cosmetic. A public sample video is always used so nothing is stored on a server.',
  },
  {
    q: 'What would a real backend need?',
    a: 'User authentication, object storage (e.g. S3 or Cloudflare R2), a database for projects and payment status, payment provider webhooks, secure signed download URLs, and proper access control.',
  },
  {
    q: 'Is my data private?',
    a: 'All state lives in browser memory for the current session. Nothing is sent to a backend. Refreshing the page resets projects to the built-in sample set (except for projects you created in the same session).',
  },
];

export default function Help() {
  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-16">
        <h1 className="text-3xl font-bold text-white">Help & FAQ</h1>
        <p className="mt-2 text-gray-400">
          Answers about the EditLock demo and how the interactions work.
        </p>

        <div className="mt-10 space-y-4">
          {faqs.map((item) => (
            <div key={item.q} className="card">
              <h3 className="font-semibold text-white">{item.q}</h3>
              <p className="mt-2 text-sm leading-relaxed text-gray-400">{item.a}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
