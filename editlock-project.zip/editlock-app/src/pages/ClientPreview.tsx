import { useParams, Link } from 'react-router-dom';
import { useDemo } from '../context/DemoContext';
import VideoPlayer from '../components/VideoPlayer';
import { PaymentBadge } from '../components/StatusBadge';
import { Lock, Download, CreditCard } from 'lucide-react';
import DemoBanner from '../components/DemoBanner';

export default function ClientPreview() {
  const { link } = useParams<{ link: string }>();
  const { projects } = useDemo();
  const project = projects.find((p) => p.privateLink === link);

  if (!project) {
    return (
      <section className="mx-auto max-w-lg px-4 py-20 text-center">
        <h1 className="text-2xl font-bold text-white">Preview not found</h1>
        <p className="mt-2 text-gray-400">This private link does not match any demo project.</p>
        <Link to="/" className="btn-primary mt-6 inline-flex">
          Go Home
        </Link>
      </section>
    );
  }

  const isUnlocked = project.paymentStatus === 'verified' || project.status === 'unlocked' || project.status === 'completed';

  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-4xl px-4 py-8 sm:px-6 sm:py-12">
        <div className="text-center">
          <p className="text-sm font-medium text-accent">Client Preview</p>
          <h1 className="mt-1 text-2xl font-bold text-white sm:text-3xl">{project.title}</h1>
          <p className="mt-2 text-gray-400">
            Prepared for {project.clientName} · <PaymentBadge status={project.paymentStatus} />
          </p>
        </div>

        <div className="mt-8">
          <VideoPlayer
            src={project.previewUrl}
            watermark={isUnlocked ? undefined : project.watermarkText}
            title={isUnlocked ? 'Final version available' : 'Watermarked preview – for review only'}
          />
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <div className="card">
            <h3 className="font-semibold text-white">Project details</h3>
            <p className="mt-2 text-sm text-gray-400">{project.description}</p>
            <p className="mt-3 text-sm text-gray-300">
              Amount due: <strong className="text-white">{project.currency} {project.amount.toLocaleString()}</strong>
            </p>
          </div>
          <div className="card">
            <h3 className="font-semibold text-white">Download status</h3>
            {isUnlocked ? (
              <div className="mt-3">
                <p className="text-sm text-emerald-400">Payment verified. Final file is unlocked.</p>
                <Link to={`/download/${project.id}`} className="btn-primary mt-4 w-full">
                  <Download className="h-4 w-4" />
                  Go to Download
                </Link>
              </div>
            ) : (
              <div className="mt-3">
                <div className="flex items-center gap-2 text-amber-400">
                  <Lock className="h-4 w-4" />
                  <span className="text-sm font-medium">Final download is locked</span>
                </div>
                <p className="mt-2 text-sm text-gray-400">
                  Complete payment to unlock the clean master file. This demo lets the editor simulate verification.
                </p>
                <Link to={`/payment/${project.id}`} className="btn-secondary mt-4 w-full">
                  <CreditCard className="h-4 w-4" />
                  View Payment Status
                </Link>
              </div>
            )}
          </div>
        </div>

        <p className="mt-8 text-center text-xs text-gray-500">
          This is a demo client view. No real payment or download occurs.
        </p>
      </section>
    </>
  );
}
