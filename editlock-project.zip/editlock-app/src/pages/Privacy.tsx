import DemoBanner from '../components/DemoBanner';

export default function Privacy() {
  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-16">
        <h1 className="text-3xl font-bold text-white">Privacy Policy</h1>
        <p className="mt-2 text-sm text-gray-500">Placeholder — Demo version</p>

        <div className="prose prose-invert mt-8 max-w-none space-y-4 text-sm text-gray-300">
          <p>
            EditLock Demo does not collect, transmit, or store personal data on any server.
          </p>
          <ul className="list-disc space-y-2 pl-5">
            <li>Form inputs (name, email, project details) remain in the browser and are discarded when the page is closed or refreshed (except for the in-session demo state).</li>
            <li>No analytics, tracking pixels, or third-party advertising scripts are included in this demo.</li>
            <li>Sample videos are loaded from public Google Cloud Storage buckets used by common video demos; they contain no personal data.</li>
            <li>Payment status changes affect only local React state.</li>
          </ul>
          <p>
            A production service would publish a full privacy policy covering data controllers, processing purposes, retention, third-party processors (storage, payments, email), user rights, and contact information. That policy does not apply to this demonstration.
          </p>
        </div>
      </section>
    </>
  );
}
