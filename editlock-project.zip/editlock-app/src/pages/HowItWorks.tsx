import { Link } from 'react-router-dom';
import { Upload, Link2, Eye, CreditCard, Unlock, CheckCircle } from 'lucide-react';
import DemoBanner from '../components/DemoBanner';

const steps = [
  {
    num: '01',
    icon: Upload,
    title: 'Upload your project',
    desc: 'Create a project, add client details, set the amount, and upload your final video. In this demo the upload is simulated with sample media.',
  },
  {
    num: '02',
    icon: Link2,
    title: 'Generate a private preview link',
    desc: 'EditLock creates a unique private link. Share it only with your client. The preview is watermarked so the file cannot be used as final delivery.',
  },
  {
    num: '03',
    icon: Eye,
    title: 'Client reviews the watermarked preview',
    desc: 'Your client opens the link, watches the preview, and can approve the work or request changes before paying.',
  },
  {
    num: '04',
    icon: CreditCard,
    title: 'Payment is verified',
    desc: 'In a production system, payment webhooks or manual verification would update the status. This demo lets you toggle the status to simulate verification.',
  },
  {
    num: '05',
    icon: Unlock,
    title: 'Final download unlocks',
    desc: 'Once payment status is verified, the clean final file becomes available for the client to download.',
  },
];

export default function HowItWorks() {
  return (
    <>
      <DemoBanner />
      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-3xl font-bold text-white sm:text-4xl">How EditLock Works</h1>
          <p className="mt-4 text-gray-400">
            A simple, transparent flow that keeps control of the final deliverable with the editor until payment is confirmed.
          </p>
        </div>

        <div className="mt-14 space-y-8">
          {steps.map((step, i) => (
            <div
              key={step.num}
              className="card flex flex-col gap-6 sm:flex-row sm:items-start"
            >
              <div className="flex shrink-0 items-center gap-4">
                <span className="text-3xl font-bold text-accent/40">{step.num}</span>
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent/15 text-accent">
                  <step.icon className="h-6 w-6" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-white">{step.title}</h3>
                <p className="mt-2 text-gray-400">{step.desc}</p>
              </div>
              {i < steps.length - 1 && (
                <div className="hidden h-full w-px bg-navy-600 sm:block" />
              )}
            </div>
          ))}
        </div>

        <div className="mt-14 card bg-navy-700/50 text-center">
          <CheckCircle className="mx-auto h-10 w-10 text-accent" />
          <h2 className="mt-4 text-xl font-semibold text-white">Ready to try the flow?</h2>
          <p className="mt-2 text-gray-400">
            Use the demo dashboard to create a project, open the client preview, and simulate payment verification.
          </p>
          <div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/dashboard" className="btn-primary">
              Go to Dashboard
            </Link>
            <Link to="/upload" className="btn-secondary">
              Upload Demo Project
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
