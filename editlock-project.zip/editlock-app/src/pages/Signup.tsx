import { FormEvent, useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDemo } from '../context/DemoContext';
import { Lock } from 'lucide-react';
import DemoBanner from '../components/DemoBanner';

export default function Signup() {
  const { login, isLoggedIn } = useDemo();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    if (isLoggedIn) navigate('/dashboard');
  }, [isLoggedIn, navigate]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    login();
    navigate('/dashboard');
  };

  return (
    <>
      <DemoBanner />
      <section className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-4 py-12">
        <div className="text-center">
          <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-accent">
            <Lock className="h-6 w-6 text-white" />
          </span>
          <h1 className="mt-4 text-2xl font-bold text-white">Create account</h1>
          <p className="mt-1 text-sm text-gray-400">Demo signup — data is not stored</p>
        </div>

        <form onSubmit={handleSubmit} className="card mt-8 space-y-4">
          <div>
            <label className="label" htmlFor="name">Full name</label>
            <input
              id="name"
              className="input"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Alex Rivera"
              required
            />
          </div>
          <div>
            <label className="label" htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
            />
          </div>
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>
          <button type="submit" className="btn-primary w-full">
            Start Free Demo
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-gray-400">
          Already have an account?{' '}
          <Link to="/login" className="text-accent hover:underline">
            Sign in
          </Link>
        </p>
        <p className="mt-2 text-center text-xs text-gray-500">
          This creates a temporary demo session only. No account is registered on a server.
        </p>
      </section>
    </>
  );
}
